//: Playground - noun: a place where people can play

import UIKit

// example 1
var n = 2
while n < 100 {
    n *= 2
}
print(n)

// example 2
var m = 2
repeat {
    m *= 2
} while m < 100
print(m)

// example 3
var total = 0
for i in 0 ..< 4 {
    total += i
}
print(total)

// example 4
func greet(person: String, day: String) ->
        String {
    return "Hello \(person), today is \(day)."
}
greet(person: "Shelby", day: "Friday")

func printRatio(waist: Double, hips: Double) ->
        Double {
        let ratio = waist / hips
            return ratio
}
printRatio(waist: 27.0, hips: 45.0)





